function F=compute_nonlinear(Zn)
  
x1=Zn(1);  x2=Zn(2);
F=[x1*x2; 0.5*(x1^2-x2^2)];

