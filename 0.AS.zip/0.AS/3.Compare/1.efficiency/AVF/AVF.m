function [CPUtime,err,energy_err]=AVF(tau)

tic;

options=optimset;
options = optimset(options,'TolX',1e-14);
options = optimset(options,'TolFun',1e-14);
options = optimset(options,'MaxFunEvals',Inf);
options=optimset(options,'Display','off');
options=optimset(options,'Algorithm','levenberg-marquardt');


rho=10;  L=rho*[0 -1;1 0];  Zn=[-1;2];
func_f=@(X)[X(1)*X(2); 0.5*(X(1)^2-X(2)^2)];
[GP,GW]=generate_GP_GW;

T=1;  tn=0;  Energy=compute_energy(Zn,rho);
while (tn<(T-0.5*tau)) 
    Zn=fsolve(@(Zn1)equation(Zn1,Zn,tau,L,GP,GW,func_f),Zn,options);  tn=tn+tau;
    Energy=[Energy compute_energy(Zn,rho)];
end
toc;  CPUtime=toc;
load reference.mat;  err=max(abs(Zn-Zn_c_100000));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));