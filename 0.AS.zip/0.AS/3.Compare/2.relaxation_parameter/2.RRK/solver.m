function [tmesh,GAMMA]=solver(tau,method)

rho=50;  L=rho*[0 -1;1 0];  Zn=[-1;2];

[A,b]=generate_method_coefficient(method);  s=size(A,1);

T=20;  tn=0;  tmesh=tn;  GAMMA=[];
while (tn<(T-tau))
    Zmid(:,1)=Zn;  
    Fmid(:,1)=compute_nonlinear(Zmid(:,1));  %%%%
    for k=2:s
        Zmid(:,k)=Zn+tau*(L*Zmid(:,1:(k-1))+Fmid(:,1:(k-1)))*(A(k,1:(k-1)))';
        Fmid(:,k)=compute_nonlinear(Zmid(:,k));  %%%%
    end
    Update=tau*(L*Zmid+Fmid)*b';  Update_norm=sum(abs(Update).^2);
    energy_old=compute_energy(Zn,rho);  %%%%    
    if ( Update_norm==0 )
        gamma=1;
    else
        gamma=fzero(@(gamma)func_of_gamma(Zn,Update,rho,energy_old,gamma),1);  %%%%
    end
    fprintf('tn=%d,distance=%d\n',tn,abs(gamma-1));
    GAMMA=[GAMMA gamma];
    Zn_save=Zn;  tn_save=tn;
    Zn=Zn+gamma*Update;  tn=tn+gamma*tau
    tmesh=[tmesh tn];
end