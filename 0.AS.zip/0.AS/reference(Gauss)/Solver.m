function Zn=Solver(tau)
T=1;

w1=1/8-sqrt(30)/144;  w2=0.5*sqrt((15+2*sqrt(30))/35);  w3=w2*(1/6+sqrt(30)/24); 
w4=w2*(1/21+5*sqrt(30)/168);  w5=w2-2*w3;
w11=1/8+sqrt(30)/144;  w22=0.5*sqrt((15-2*sqrt(30))/35);  w33=w22*(1/6-sqrt(30)/24); 
w44=w22*(1/21-5*sqrt(30)/168);  w55=w22-2*w33;
A=[w1 w11-w3+w44 w11-w3-w44 w1-w5; ... 
   w1-w33+w4 w11 w11-w55 w1-w33-w4; ...
   w1+w33+w4 w11+w55 w11 w1+w33-w4; ...
   w1+w5 w11+w3+w44 w11+w3-w44 w1];
b=[2*w1 2*w11 2*w11 2*w1];
c=[0.5-w2; 0.5-w22; 0.5+w22; 0.5+w2];

rho=10;  
L=rho*[0 -1;1 0];  d=size(L,1);  s=size(b,2);  Id=eye(d);  Ids=eye(d*s);  es=ones(s,1); 
k_A_Id=kron(A,Id);  k_A_L=kron(A,L);  k_b_Id=kron(b,Id);  k_b_L=kron(b,L);
Zn=[-1;2];

for k=1:round(T/tau)
    k_es_Zn=kron(es,Zn);  Zmid=k_es_Zn;  Iter_err=1;  count=0; 
    while (Iter_err>10^(-16) && count < 100)
        F=compute_nonlinear(Zmid,d,s);
        Vector=Zmid-k_es_Zn-tau*k_A_L*Zmid-tau*k_A_Id*F; 
        F_der=compute_nonlinear_der(Zmid,d,s);
        Matrix=Ids-tau*k_A_L-tau*k_A_Id*F_der;
        Zmid_save=Zmid;
        Zmid=Zmid-Matrix\Vector;
        Iter_err=max(abs(Zmid-Zmid_save));
        count=count+1;
    end
    F=compute_nonlinear(Zmid,d,s);
    Zn=Zn+tau*k_b_L*Zmid+tau*k_b_Id*F;
    k
end

