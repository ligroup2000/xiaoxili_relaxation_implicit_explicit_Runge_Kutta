function F=compute_nonlinear(Zmid,d,s)

Zmid_reshape=reshape(Zmid,d,s);  
x1=Zmid_reshape(1,:);
x2=Zmid_reshape(2,:);
F=[x1.*x2; 0.5*(x1.^2-x2.^2)];
F=F(:);
