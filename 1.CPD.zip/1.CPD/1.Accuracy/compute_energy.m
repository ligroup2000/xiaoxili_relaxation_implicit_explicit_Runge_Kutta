function result=compute_energy(Zn,m)

V=Zn(1:m);  X=Zn(m+1:2*m);
result=0.5*real(V'*V)+2*(X(1)^2+X(2)^2+X(3)^2)+sin(X(1)+X(2)+X(3));