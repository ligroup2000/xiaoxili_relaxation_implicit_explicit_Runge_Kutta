function F=compute_nonlinear(Zn,m)
  
X1=Zn(m+1);  X2=Zn(m+2);  X3=Zn(m+3);  val=cos(X1+X2+X3);
F=[4*X1+val;4*X2+val;4*X3+val;zeros(m,1)];  F=-F;

