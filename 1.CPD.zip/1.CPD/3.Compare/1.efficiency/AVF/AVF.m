function [CPUtime,err,energy_err]=AVF(tau)

tic;

options=optimset;
options = optimset(options,'TolX',1e-14);
options = optimset(options,'TolFun',1e-14);
options = optimset(options,'MaxFunEvals',Inf);
options=optimset(options,'Display','off');
options=optimset(options,'Algorithm','levenberg-marquardt');


m=3;  epsilon=0.1;  Im=eye(m);  om=zeros(m,m);
B=[0 1 0;-1 0 0;0 0 0];  S=[(1/epsilon)*B -Im;Im om];  Q=[Im om;om om];  L=S*Q;
Vn=[0.09;0.05;0.2];  Xn=[0;1;0.1];  Zn=[Vn;Xn];
func_f=@(X)[-4*X(1)-cos(X(1)+X(2)+X(3));-4*X(2)-cos(X(1)+X(2)+X(3));-4*X(3)-cos(X(1)+X(2)+X(3))];
[GP,GW]=generate_GP_GW;

T=1;  tn=0;  Energy=compute_energy(Zn,m);
while (tn<(T-0.5*tau)) 
    Zn=fsolve(@(Zn1)equation(Zn1,Zn,tau,L,m,GP,GW,func_f),Zn,options);  tn=tn+tau;
    Energy=[Energy compute_energy(Zn,m)];
end
toc;  CPUtime=toc;
load reference.mat;  err=max(abs(Zn-Zn_Gauss4_10000));
energy_err=mean(abs(Energy-Energy(1))/abs(Energy(1)));