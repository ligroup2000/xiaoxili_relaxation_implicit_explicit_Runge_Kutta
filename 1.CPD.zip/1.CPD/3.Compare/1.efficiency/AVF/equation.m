function result=equation(Zn1,Zn,tau,L,m,GP,GW,func_f)

Xn1=Zn1(m+1:end,1);  Xn=Zn(m+1:end,1);  new=Xn1-Xn;
X1=Xn+GP(1)*new;  X2=Xn+GP(2)*new;  X3=Xn+GP(3)*new;  X4=Xn+GP(4)*new;  X5=Xn+GP(5)*new;
F=GW(1)*func_f(X1)+GW(2)*func_f(X2)+GW(3)*func_f(X3)+GW(4)*func_f(X4)+GW(5)*func_f(X5);
result=Zn1-Zn-0.5*tau*L*(Zn1+Zn)-tau*[F;zeros(m,1)];