function result=equation(ZZ,Zn,tau,L,om1,m,coe1,coe2,coe3,coe4,coe5,coe6,GW,func_f)

Zm=ZZ(1:2*m,1);  Zn1=ZZ(2*m+1:end,1);  
Xn=Zn(m+1:end,1);  Xm=Zm(m+1:end,1);  Xn1=Zn1(m+1:end,1);
Yn=L*Zn;  Ym=L*Zm;  Yn1=L*Zn1;  
L1=coe5(1)*Yn+coe5(2)*Ym+coe5(3)*Yn1;  L2=coe6(1)*Yn+coe6(2)*Ym+coe6(3)*Yn1;
X1=coe1(1)*Xn+coe2(1)*Xm+coe3(1)*Xn1;  X2=coe1(2)*Xn+coe2(2)*Xm+coe3(2)*Xn1;
X3=coe1(3)*Xn+coe2(3)*Xm+coe3(3)*Xn1;  X4=coe1(4)*Xn+coe2(4)*Xm+coe3(4)*Xn1;
X5=coe1(5)*Xn+coe2(5)*Xm+coe3(5)*Xn1;
FF1=func_f(X1);  FF2=func_f(X2);  FF3=func_f(X3);  FF4=func_f(X4);  FF5=func_f(X5);
F1=coe4(1)*FF1+coe4(2)*FF2+coe4(3)*FF3+coe4(4)*FF4+coe4(5)*FF5;
F2=GW(1)*FF1+GW(2)*FF2+GW(3)*FF3+GW(4)*FF4+GW(5)*FF5;
result=ZZ-[Zn;Zn]-tau*[L1;L2]-tau*[F1;om1;F2;om1];