function F=compute_nonlinear(Zn,func_f,N)

Un_p=real(N*ifft(Zn(N+1:2*N,:)));  
F=[(1/N)*fft(func_f(Un_p)); zeros(N,1)];


