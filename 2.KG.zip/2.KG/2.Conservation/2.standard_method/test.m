[tmesh,Energy,CPUtime,tau]=solver(1/3000,'IERK2');
save('IERK2.mat','tmesh','Energy','CPUtime','tau');
clear; clc;
[tmesh,Energy,CPUtime,tau]=solver(1/4000,'IERK3');
save('IERK3.mat','tmesh','Energy','CPUtime','tau');
clear; clc;
[tmesh,Energy,CPUtime,tau]=solver(1/2500,'IERK4');
save('IERK4.mat','tmesh','Energy','CPUtime','tau');