function [Xn_t,t]=Solver(tau)
T=1;
%%%%%%%%%%%%%%%% 2-stages %%%%%%%%%%%%%%%%
% Gauss
% A=[1/4 1/4-sqrt(3)/6; 1/4+sqrt(3)/6 1/4];
% b=[1/2 1/2];
% c=[1/2-sqrt(3)/6; 1/2+sqrt(3)/6];
%%%%%%%%%%%%%%%% 3-stages %%%%%%%%%%%%%%%%
% Gauss
% A=[5/36 2/9-sqrt(15)/15 5/36-sqrt(15)/30; ...
%    5/36+sqrt(15)/24 2/9 5/36-sqrt(15)/24; ...
%    5/36+sqrt(15)/30 2/9+sqrt(15)/15 5/36];
% b=[5/18 4/9 5/18];
% c=[1/2-sqrt(15)/10; 1/2; 1/2+sqrt(15)/10];
%%%%%%%%%%%%%%%% 4-stages %%%%%%%%%%%%%%%%
% Gauss
w1=1/8-sqrt(30)/144;  w2=0.5*sqrt((15+2*sqrt(30))/35);  w3=w2*(1/6+sqrt(30)/24); 
w4=w2*(1/21+5*sqrt(30)/168);  w5=w2-2*w3;
w11=1/8+sqrt(30)/144;  w22=0.5*sqrt((15-2*sqrt(30))/35);  w33=w22*(1/6-sqrt(30)/24); 
w44=w22*(1/21-5*sqrt(30)/168);  w55=w22-2*w33;
A=[w1 w11-w3+w44 w11-w3-w44 w1-w5; ... 
   w1-w33+w4 w11 w11-w55 w1-w33-w4; ...
   w1+w33+w4 w11+w55 w11 w1+w33-w4; ...
   w1+w5 w11+w3+w44 w11+w3-w44 w1];
b=[2*w1 2*w11 2*w11 2*w1];
c=[0.5-w2; 0.5-w22; 0.5+w22; 0.5+w2];

N=100;  left=0;  right=1.28;  LL=right-left;  h=LL/N;  xmesh=left:h:right-h;  
freq=(2*pi/LL)*[0:N/2-1 -N/2:-1];  K=diag(freq.^2);  L=[zeros(N,N) -K; eye(N) zeros(N,N)];
s=size(A,1);  es=ones(s,1);  Id=speye(2*N);  
AI=kron(A,Id);  bI=kron(b,Id);  Matrix=(eye(2*s*N)-tau*kron(A,L))^(-1);  bL=kron(b,L);
t=0;  Xn_t=[zeros(1,N) (1/N)*(fft(20*(1+cos((2*pi/LL)*xmesh'))))']'; 
func_f=@(x)(-1)*(x.^3+x); 

for k=1:round(T/tau)
    Iter_err=1;  ccout=0;  Xmid_t=kron(es,Xn_t);
    while (Iter_err > 10^(-14) && ccout < 100)
        Xmid_t_c=reshape(Xmid_t,2*N,s);  Umid_c=real(N*ifft(Xmid_t_c(N+1:2*N,:)));  
        fmid_t_c=(1/N)*fft(func_f(Umid_c));  Fmid_t_c=[fmid_t_c; zeros(N,s)];
        F=kron(es,Xn_t)+tau*AI*Fmid_t_c(:); 
        Xmid_t_save=Xmid_t;  Xmid_t=Matrix*F;
        Iter_err=max(abs(Xmid_t-Xmid_t_save));
        ccout=ccout+1;
    end
    Xmid_t_c=reshape(Xmid_t,2*N,s);  Umid_c=real(N*ifft(Xmid_t_c(N+1:2*N,:)));  
    fmid_t_c=(1/N)*fft(func_f(Umid_c));  Fmid_t_c=[fmid_t_c; zeros(N,s)];
    Update=tau*bL*Xmid_t+tau*bI*Fmid_t_c(:);
    Xn_t=Xn_t+Update;
    t=t+tau; 
    k
end
