function result=compute_energy(X_t,N,LL,K,h,func_F)

V_t=X_t(1:N,1);  U_t=X_t(N+1:2*N,1);
result=0.5*LL*abs(V_t'*V_t)+0.5*LL*abs(U_t'*K*U_t)-h*sum(func_F(real(N*ifft(U_t))));

