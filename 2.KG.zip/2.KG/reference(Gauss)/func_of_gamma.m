function result=func_of_gamma(Xn_t,Update,N,LL,K,h,func_F,energy_old,gamma)

result=compute_energy(Xn_t+gamma*Update,N,LL,K,h,func_F)-energy_old;