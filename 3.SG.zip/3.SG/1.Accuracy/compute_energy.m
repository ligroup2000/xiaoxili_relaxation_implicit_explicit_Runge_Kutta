function result=compute_energy(Zn,d,h,func_F,K)


V=Zn(1:d,1);  U=Zn(d+1:2*d,1);
result=0.5*h*h*(V'*V)-0.5*h*h*(U'*K*U)-h*h*sum(func_F(U));