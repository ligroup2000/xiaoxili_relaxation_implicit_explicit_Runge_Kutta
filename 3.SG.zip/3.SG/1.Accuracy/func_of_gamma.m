function result=func_of_gamma(Zn,Update,d,K,h,func_F,energy_old,gamma)

result=compute_energy(Zn+gamma*Update,d,h,func_F,K)-energy_old;