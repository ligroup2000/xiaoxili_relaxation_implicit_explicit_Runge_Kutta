method='IERK2';
stepsize=[1/8 1/16 1/32 1/64 1/128];

Gamma_average_save=[];  err=[];  load('reference.mat')
for k=1:size(stepsize,2)
    tau=stepsize(1,k);
    [Zn,gamma_average]=solver(tau,method); 
    Gamma_average_save=[Gamma_average_save gamma_average]; 
    err=[err max(abs(Zn-Xn_Gauss4_1000))];
end


err 
Err_order=log(err(1:end-1)./err(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
Gamma_average_save
Gamma_average_order=log(Gamma_average_save(1:end-1)./Gamma_average_save(2:end))./log(stepsize(1:end-1)./stepsize(2:end))